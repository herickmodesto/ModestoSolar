-- ============================================================
-- FRACTALIZE — schema multi-tenant (Supabase / Postgres)
-- Rode no SQL Editor do Supabase, de cima para baixo.
-- ============================================================

-- ------------------------------------------------------------
-- 1. PERFIS (espelha auth.users)
-- ------------------------------------------------------------
create table public.perfis (
  id          uuid primary key references auth.users(id) on delete cascade,
  nome        text,
  telefone    text,
  criado_em   timestamptz not null default now()
);

-- cria o perfil automaticamente no cadastro
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.perfis (id, nome)
  values (new.id, new.raw_user_meta_data->>'nome');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();


-- ------------------------------------------------------------
-- 2. LOJAS (o tenant)
-- ------------------------------------------------------------
create table public.lojas (
  id                 uuid primary key default gen_random_uuid(),
  owner_id           uuid not null references auth.users(id) on delete cascade,

  -- identidade / roteamento
  slug               text not null unique,          -- vira {slug}.fractalize.com
  dominio_proprio    text unique,                   -- futuro: cardapio.divinocrepe.com.br

  -- dados da loja (o que hoje está em src/data/config.js)
  nome               text not null,
  descricao          text,
  whatsapp           text,                          -- E.164: 5535999999999
  endereco           text,
  instagram          text,
  logo_url           text,
  capa_url           text,
  nota_promo         text,
  horarios           jsonb not null default '{}'::jsonb,
  taxa_entrega       numeric(10,2),
  pix_chave          text,

  -- aparência
  tema               text not null default 'dark',
  cor_primaria       text not null default '#f97316',

  -- estado
  publicada          boolean not null default false,
  criado_em          timestamptz not null default now(),
  atualizado_em      timestamptz not null default now(),

  constraint slug_formato check (slug ~ '^[a-z0-9]([a-z0-9-]{1,48}[a-z0-9])$'),
  constraint slug_reservado check (
    slug not in ('www','app','admin','api','painel','auth','login','cdn',
                 'mail','blog','docs','status','static','assets','fractalize')
  )
);

create index lojas_owner_idx on public.lojas (owner_id);
create index lojas_slug_idx  on public.lojas (slug);


-- ------------------------------------------------------------
-- 3. ASSINATURAS (cobrança mensal)
-- ------------------------------------------------------------
create type public.status_assinatura as enum
  ('trial','ativa','pendente','inadimplente','cancelada');

create table public.assinaturas (
  id                  uuid primary key default gen_random_uuid(),
  loja_id             uuid not null unique references public.lojas(id) on delete cascade,
  status              public.status_assinatura not null default 'trial',
  plano               text not null default 'essencial',
  valor_centavos      integer not null default 0,
  gateway             text,                     -- 'stripe' | 'asaas' | 'mercadopago'
  gateway_customer_id text,
  gateway_sub_id      text,
  trial_termina_em    timestamptz not null default now() + interval '14 days',
  periodo_termina_em  timestamptz,
  cancelada_em        timestamptz,
  atualizado_em       timestamptz not null default now()
);

create index assinaturas_loja_idx on public.assinaturas (loja_id);

-- toda loja nasce com uma assinatura em trial
create or replace function public.handle_new_loja()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.assinaturas (loja_id) values (new.id);
  return new;
end;
$$;

create trigger on_loja_created
  after insert on public.lojas
  for each row execute function public.handle_new_loja();


-- ------------------------------------------------------------
-- 4. CATEGORIAS
-- ------------------------------------------------------------
create table public.categorias (
  id        uuid primary key default gen_random_uuid(),
  loja_id   uuid not null references public.lojas(id) on delete cascade,
  nome      text not null,
  ordem     integer not null default 0,
  ativa     boolean not null default true,
  criado_em timestamptz not null default now()
);

create index categorias_loja_idx on public.categorias (loja_id, ordem);


-- ------------------------------------------------------------
-- 5. ITENS DO CARDÁPIO (o que hoje está em src/data/menu.js)
-- ------------------------------------------------------------
create table public.itens (
  id           uuid primary key default gen_random_uuid(),
  loja_id      uuid not null references public.lojas(id) on delete cascade,
  categoria_id uuid references public.categorias(id) on delete set null,
  nome         text not null,
  descricao    text,
  preco        numeric(10,2),          -- NULL = "A consultar"
  imagem_url   text,
  destaque     boolean not null default false,
  ativo        boolean not null default true,
  ordem        integer not null default 0,
  criado_em    timestamptz not null default now()
);

create index itens_loja_idx      on public.itens (loja_id, ordem);
create index itens_categoria_idx on public.itens (categoria_id);


-- ------------------------------------------------------------
-- 6. PEDIDOS (histórico — o WhatsApp continua sendo o canal)
-- ------------------------------------------------------------
create table public.pedidos (
  id             uuid primary key default gen_random_uuid(),
  loja_id        uuid not null references public.lojas(id) on delete cascade,
  cliente_nome   text,
  cliente_fone   text,
  endereco       text,
  pagamento      text,
  observacoes    text,
  itens_snapshot jsonb not null,        -- congela nome/preço no momento do pedido
  total          numeric(10,2) not null,
  status         text not null default 'novo',
  criado_em      timestamptz not null default now()
);

create index pedidos_loja_idx on public.pedidos (loja_id, criado_em desc);


-- ============================================================
-- 7. HELPERS DE SEGURANÇA
-- ============================================================

-- dono da loja? (security definer evita recursão de RLS)
create or replace function public.e_dono(p_loja_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.lojas
    where id = p_loja_id and owner_id = auth.uid()
  );
$$;

-- loja visível publicamente? (publicada E assinatura em dia)
create or replace function public.loja_visivel(p_loja_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1
    from public.lojas l
    join public.assinaturas a on a.loja_id = l.id
    where l.id = p_loja_id
      and l.publicada = true
      and (
        a.status = 'ativa'
        or (a.status = 'trial' and a.trial_termina_em > now())
      )
  );
$$;


-- ============================================================
-- 8. ROW LEVEL SECURITY
-- ============================================================
alter table public.perfis      enable row level security;
alter table public.lojas       enable row level security;
alter table public.assinaturas enable row level security;
alter table public.categorias  enable row level security;
alter table public.itens       enable row level security;
alter table public.pedidos     enable row level security;

-- --- perfis ---
create policy "perfil próprio: leitura" on public.perfis
  for select using (id = auth.uid());
create policy "perfil próprio: escrita" on public.perfis
  for update using (id = auth.uid());

-- --- lojas ---
create policy "loja: dono faz tudo" on public.lojas
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "loja: leitura pública se publicada" on public.lojas
  for select using (public.loja_visivel(id));

-- --- assinaturas (só leitura pelo dono; escrita só via service_role/webhook) ---
create policy "assinatura: dono lê" on public.assinaturas
  for select using (public.e_dono(loja_id));

-- --- categorias ---
create policy "categoria: dono faz tudo" on public.categorias
  for all using (public.e_dono(loja_id)) with check (public.e_dono(loja_id));

create policy "categoria: leitura pública" on public.categorias
  for select using (ativa and public.loja_visivel(loja_id));

-- --- itens ---
create policy "item: dono faz tudo" on public.itens
  for all using (public.e_dono(loja_id)) with check (public.e_dono(loja_id));

create policy "item: leitura pública" on public.itens
  for select using (ativo and public.loja_visivel(loja_id));

-- --- pedidos ---
create policy "pedido: dono lê" on public.pedidos
  for select using (public.e_dono(loja_id));

create policy "pedido: qualquer um cria em loja visível" on public.pedidos
  for insert with check (public.loja_visivel(loja_id));


-- ============================================================
-- 9. STORAGE (imagens de itens e logos)
-- Crie o bucket 'cardapios' como PÚBLICO no painel do Supabase.
-- Convenção de path: {loja_id}/{arquivo}
-- ============================================================
create policy "cardapios: leitura pública" on storage.objects
  for select using (bucket_id = 'cardapios');

create policy "cardapios: dono envia" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'cardapios'
    and public.e_dono((storage.foldername(name))[1]::uuid)
  );

create policy "cardapios: dono apaga" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'cardapios'
    and public.e_dono((storage.foldername(name))[1]::uuid)
  );
