# Fractalize — Arquitetura e Roadmap

Plataforma onde cada cliente cria seu próprio cardápio web, acessível em
`{loja}.fractalize.com`, com finalização de pedido pelo WhatsApp.

**Decisões travadas:** Supabase (auth + Postgres + storage) · subdomínio por loja ·
assinatura mensal desde o início.

---

## 1. Arquitetura

Um único projeto Next.js (App Router) servindo três superfícies, separadas por
route group:

```
fractalize.com              → landing, preços, cadastro
app.fractalize.com          → painel do lojista (área logada)
{loja}.fractalize.com       → cardápio público, renderizado no servidor
```

O `middleware.ts` lê o `Host` da requisição, extrai o subdomínio e reescreve a
rota internamente. A URL que o cliente final vê nunca muda.

```
divino-crepe.fractalize.com/  →  (rewrite)  →  /_sites/divino-crepe
```

### Por que Next.js e não continuar no Vite

O app atual é SPA pura. Para cardápio isso custa caro em dois pontos concretos:

- **Preview de link no WhatsApp** — que é exatamente onde esses links circulam.
  SPA entrega HTML vazio, então o preview sai sem nome, sem logo, sem descrição.
  Com SSR você gera `generateMetadata()` por loja e cada link aparece com a marca
  do lojista.
- **Google** — cada cardápio precisa ser indexável isoladamente.

O CSS puro e os componentes que você já tem (`ItemCard`, `CartPanel`, `Toolbar`,
`Toast`, `Header`, `Hero`) migram quase sem alteração — muda a origem dos dados,
não a UI. `'use client'` no topo dos que usam estado e pronto.

### Fluxo de dados

| Hoje (Divino Crepe) | No Fractalize |
|---|---|
| `src/data/config.js` | linha na tabela `lojas` |
| `src/data/menu.js` | tabelas `categorias` + `itens` |
| build por loja | uma query por slug, no servidor |

---

## 2. Banco

Ver `schema.sql` — cole no SQL Editor do Supabase e rode de cima para baixo.

Tabelas: `perfis`, `lojas`, `assinaturas`, `categorias`, `itens`, `pedidos`.

**O ponto mais importante do arquivo é o RLS.** Duas funções governam tudo:

- `e_dono(loja_id)` — o lojista só enxerga e edita o que é dele.
- `loja_visivel(loja_id)` — o público só lê lojas **publicadas E com assinatura em
  dia**. Ou seja: a inadimplência derruba o cardápio automaticamente, no banco,
  sem você escrever nenhuma checagem na aplicação. É a sua régua de cobrança.

Nunca exponha a `service_role key` no cliente. Ela só existe nos webhooks e em
rotas de servidor.

---

## 3. Estrutura de pastas

```
src/
├── middleware.ts                  # resolve subdomínio → tenant
├── app/
│   ├── (marketing)/               # fractalize.com
│   │   ├── page.tsx               # landing + preços
│   │   ├── entrar/
│   │   └── cadastro/
│   ├── (painel)/painel/           # app.fractalize.com — protegido
│   │   ├── layout.tsx             # guarda de sessão + sidebar
│   │   ├── cardapio/              # CRUD de categorias e itens
│   │   ├── loja/                  # config: whatsapp, endereço, horário, tema
│   │   ├── pedidos/
│   │   └── assinatura/
│   ├── _sites/[slug]/             # o cardápio público (destino do rewrite)
│   │   ├── page.tsx               # server component: busca loja + itens
│   │   └── opengraph-image.tsx    # preview do WhatsApp, por loja
│   └── api/webhooks/pagamento/    # atualiza assinaturas.status
├── components/                    # seus componentes atuais, portados
├── lib/supabase/                  # clients: browser, server, admin
└── styles/global.css              # o seu CSS, com CSS vars por loja
```

Tematização por loja sem recompilar: injete `--cor-primaria` num `<style>` inline
no layout do site público, alimentado por `loja.cor_primaria`.

---

## 4. DNS e deploy (Vercel)

Wildcard funciona em qualquer plano, mas com uma exigência específica:
<cite index="6-1">o suporte a domínios wildcard (`*.acme.com`) está disponível em todos os planos, com o requisito de usar os nameservers da Vercel para a geração do certificado SSL wildcard</cite>.

Passos:

1. Aponte `fractalize.com` para `ns1.vercel-dns.com` e `ns2.vercel-dns.com` no
   seu registrador.
2. No projeto Vercel, adicione o domínio apex `fractalize.com`.
3. Adicione o wildcard `*.fractalize.com`.
4. Cada `loja.fractalize.com` passa a resolver sozinho, com certificado emitido
   sob demanda — sem nenhuma ação por loja nova.

> Em desenvolvimento, subdomínio local não funciona direto. Use
> `divino-crepe.localhost:3000` (Chrome resolve) ou um alias no `/etc/hosts`.

---

## 5. Cobrança

O gateway ainda não está decidido, e a escolha importa mais no Brasil do que
parece:

- **Stripe** — melhor DX, assinatura recorrente resolvida, mas cartão é o caminho
  natural. Para dono de lanchonete, cartão de crédito empresarial nem sempre existe.
- **Asaas / Pagar.me / Mercado Pago** — recorrência com **Pix e boleto**, que é
  como o pequeno comerciante brasileiro realmente paga. Fricção muito menor no
  seu público-alvo.

Independente do escolhido, o desenho é o mesmo: o gateway chama
`/api/webhooks/pagamento`, que usa a `service_role key` para atualizar
`assinaturas.status`. O RLS faz o resto — cardápio some quando fica inadimplente,
volta quando paga.

Sugestão de planos para começar: **trial de 14 dias** (já embutido no schema) →
plano único mensal. Múltiplos tiers só quando você souber o que o mercado valoriza.

---

## 6. Roadmap por fases

**Fase 1 — Fundação (1 semana)**
Criar projeto Supabase, rodar o `schema.sql`, criar bucket `cardapios`, scaffold
do Next.js, `middleware.ts` de subdomínio, DNS wildcard configurado.
*Entrega: `teste.fractalize.com` responde "olá".*

**Fase 2 — Cardápio público (1 semana)**
Portar seus componentes, trocar imports estáticos por query no Supabase, montar
`opengraph-image` dinâmico.
*Entrega: `divino-crepe.fractalize.com` idêntico ao site de hoje, servido do banco.*

**Fase 3 — Auth e painel (2 semanas)**
Cadastro/login com email e senha, criação de loja com validação de slug em tempo
real, CRUD de categorias e itens com upload de imagem, editor de config da loja,
preview.
*Entrega: um lojista consegue montar o cardápio dele sozinho, do zero.*

**Fase 4 — Cobrança (1 semana)**
Gateway, checkout, webhook, tela de assinatura, e-mails de trial expirando.
*Entrega: dá para cobrar.*

**Fase 5 — Landing e lançamento (1 semana)**
Página de vendas, onboarding, cardápio de demonstração, e o Divino Crepe migrado
como caso real.

**Depois:** domínio próprio do lojista, histórico e painel de pedidos, QR code da
mesa, cupons, relatórios, PWA.

---

## 7. Riscos que valem atenção desde já

- **Slug é para sempre.** Trocar quebra links já impressos em cardápio e adesivo.
  Reserve nomes agora (o `check` no schema já bloqueia `www`, `app`, `admin`...) e
  decida se permite troca.
- **Imagens.** Lojista sobe foto de 8 MB tirada do celular. Redimensione no
  upload (client-side, antes de mandar) ou você paga a banda e o cliente final
  espera 10 s de carregamento no 4G.
- **LGPD.** No momento em que você guardar `pedidos` com nome, telefone e endereço
  do consumidor final, você é operador de dados pessoais. Política de privacidade
  e prazo de retenção precisam existir antes do primeiro pedido real.
- **Limite do plano grátis do Supabase.** Ele pausa projeto inativo e tem teto de
  storage. Com clientes pagantes, suba para o plano pago antes, não depois.
